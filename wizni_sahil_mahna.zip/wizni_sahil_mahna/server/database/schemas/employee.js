var mongoose = require('mongoose');

var employeeSchema = new mongoose.Schema(

    {
        eId: { type: Number, unique: true },
        eName: String,
        manager: String,
        projects: Array

    }
);


var employee = mongoose.model('employee', employeeSchema);

module.exports = {
    employee: employee
}