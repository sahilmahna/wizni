var mongoose = require('mongoose');

var projectSchema = new mongoose.Schema(

    {
        pId: { type: Number, unique: true },
        pName: String,
        manager: { type: String, required: true },
        employees: Array



    }
);


var project = mongoose.model('project', projectSchema);

module.exports = {
    project: project
}