var mongoose = require('mongoose');

var managerSchema = new mongoose.Schema(

    {
        eId: { type: Number, unique: true },
        eName: String,
        employee: Array,
        project: Object

    }
);


var manager = mongoose.model('manager', managerSchema);

module.exports = {
    manager: manager
}