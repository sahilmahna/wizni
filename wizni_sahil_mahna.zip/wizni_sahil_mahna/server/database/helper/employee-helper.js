var employeeSchema = require('./../schemas/employee');
var managerSchema = require('./../schemas/manager')



function registerEmployee(object, callback) {
    const employeeData = new employeeSchema.employee(object);

    employeeData.save().then(result => {
            callback(null, "employee created");

        },
        (err) => {
            if (err.code == 11000) {
                callback("employee id already exists", null)
            }
            callback("unable to save entry");
        })


}




function updateEmployee(object, callback) {
    //$set will update only the provoded input
    employeeSchema.employee.update({ eId: object.eId }, { $set: object }).then(
        (res) => {
            if (res.nModified > 0) { callback(null, res.nModified + " documents updated"); } else
                callback(null, "Nothing to update");
        },
        (err) => { callback(err, null); }

    )


}


function getData(object, callback) {
    employeeSchema.employee.findOne(object).then((res) => {
            if (typeof res == 'undefined' || res == null)
                callback("no record found", null)
            callback(null, res)
        },
        (err) => { callback(err, null) }
    ).catch((err) => callback(err, null))
}


function getAllData(callback) {
    employeeSchema.employee.find().then((res) => {
            if (typeof res == 'undefined' || res == null)
                callback("no record found", null)
            callback(null, res)
        },
        (err) => { callback(err, null) }
    ).catch((err) => callback(err, null))
}

function deleteEmployee(object, callback) {
    employeeSchema.employee.findOne(object).then(
        (res) => {

            employeeSchema.employee.findByIdAndRemove({ "_id": res._id }).then(result => {
                    callback(null, result)

                },
                (err) => {
                    callback(err, null)
                }).catch((err) => { callback(err, null) });
        },
        (err) => { callback(err, null) }
    ).catch((err) => {
        callback(err, null)
    });
}

module.exports = {
    getData: getData,
    getAllData: getAllData,
    registerEmployee: registerEmployee,
    deleteEmployee: deleteEmployee,
    updateEmployee: updateEmployee
}