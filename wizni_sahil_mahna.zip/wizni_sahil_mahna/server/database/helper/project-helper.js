var projectSchema = require('./../schemas/project');


function getData(object, callback) {
    projectSchema.project.findOne(object).then((res) => {
            if (typeof res == 'undefined' || res == null)
                callback("no record found", null)
            callback(null, res)
        },
        (err) => { callback(err, null) }
    ).catch((err) => callback(err, null))
}


function getAllData(callback) {
    projectSchema.project.find().then((res) => {
            if (typeof res == 'undefined' || res == null)
                callback("no record found", null)
            callback(null, res)
        },
        (err) => { callback(err, null) }
    ).catch((err) => callback(err, null))
}

function registerProject(object, callback) {
    const projectData = new projectSchema.project(object);
    projectData.save().then((result) => {
            callback(null, "project Created")
        },
        (err) => {
            if (err.code == 11000) {
                callback("project already exists", null)
            }
            callback("Please enter manager name " + err, null);
        })
}

function deleteProject(object, callback) {
    projectSchema.project.findOne(object).then( //getting object from db 
        (res) => {
            projectData.project.findByIdAndRemove({ "_id": res._id }).then(result => { //deleting by objectId
                    callback(null, result)

                },
                (err) => {
                    callback(err, null)
                }).catch((err) => { callback(err, null) });
        },
        (err) => { callback(err, null) }
    ).catch((err) => {
        ccallback(err, null)
    });





}



function updateEmployee(object, callback) {
    //$set will update only the provoded input
    projectSchema.project.update({ pId: object.pId }, { $set: object }).then(
        (res) => {
            if (res.nModified > 0) { callback(null, res.nModified + " documents updated"); } else
                callback(null, "Nothing to update");
        },
        (err) => {
            callback(err, null);
        },
        (err) => { callback(err, null); }

    )


}

module.exports = {
    registerProject: registerProject,
    deleteProject: deleteProject,
    getData: getData,
    getAllData: getAllData,
    updateEmployee: updateEmployee
}