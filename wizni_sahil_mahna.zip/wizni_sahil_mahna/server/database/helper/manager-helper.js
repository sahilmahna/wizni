var managerSchema = require('./../schemas/manager');

function getData(object, callback) {
    managerSchema.manager.findOne(object).then((res) => {
            if (typeof res == 'undefined' || res == null)
                callback("no record found", null)
            callback(null, res)
        },
        (err) => { callback(err, null) }
    ).catch((err) => callback(err, null))
}


function getAllData(callback) {
    managerSchema.manager.find().then((res) => {
            if (typeof res == 'undefined' || res == null)
                callback("no record found", null)
            callback(null, res)
        },
        (err) => { callback(err, null) }
    ).catch((err) => callback(err, null))
}

function registerManager(object, callback) {
    const managerData = new managerSchema.manager(object);
    managerData.save().then(result => {
            callback(null, "Manager created")
        },
        (err) => {
            if (err.code == 11000) {
                callback("Manager id already exists", null)
            }
            callback("unable to save data", null);
        })
}

function deleteManager(object, callback) {

    managerSchema.manager.findOne(object).then(
        (res) => {
            managerSchema.manager.findByIdAndRemove({ "_id": res._id }).then(result => {
                    callback(null, result)

                },
                (err) => {
                    callback(err, null)
                }).catch((err) => { callback(err, null) });

        },
        (err) => { callback(err, null) }
    ).catch((err) => {
        callback(err, null)
    });





}



function updateEmployee(object, callback) {
    //$set will update only the provoded input
    managerSchema.manager.update({ eId: object.eId }, { $set: object }).then(
        (res) => {
            if (res.nModified > 0) { callback(null, res.nModified + " documents updated"); } else
                callback(null, "Nothing to update");
        },
        (err) => { callback(err, null); }

    )


}

module.exports = {
    registerManager: registerManager,
    deleteManager: deleteManager,
    getData: getData,
    getAllData: getAllData,
    updateEmployee: updateEmployee
}