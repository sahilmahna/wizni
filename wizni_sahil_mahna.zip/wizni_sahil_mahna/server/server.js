var http = require('http');
var mongoose = require('mongoose');
var constant = require('./constant')
var layer = require('./layer');
mongoose.Promise  =  global.Promise;

var port = 3000; //default port
if (process.argv[2]) { port = process.argv[2]; }

init();

// connecting to DB
function init() {
    mongoose.connect(constant.dbURL, function(err)

        {
            if (err) {
                console.log("error in databse connection " + err)
            } else
                console.log("db connection done mongoose")
        }

    );
}
//creating a server object:
http.createServer(function(req, res) {
    res.writeHead(200, { 'Content-Type': 'application/json' }); // http header
    switch (req.method) { //req is object containing info about requested from client

        case "GET":

            break;
        case "PUT":
            switch (req.url) {
                case "/update":
                    layer.update(req, function(err, data) {
                        if (err)
                            res.end(JSON.stringify({ statuscode: 500, response: err }));
                        else {
                            res.end(JSON.stringify({ statuscode: 200, response: data }));
                        }
                    })
            }
            break;

            break;
        case "POST":
            switch (req.url) {
                case "/create":
                    layer.create(req, function(err, data) {
                        if (err)
                            res.end(JSON.stringify({ statuscode: 500, response: err }));
                        else {
                            res.end(JSON.stringify({ statuscode: 200, response: data }));
                        }
                    })
                    break;
                case "/getData":
                    layer.getData(req, function(err, data) {
                        if (err)
                            res.end(JSON.stringify({ statuscode: 500, response: err }));
                        else {
                            res.end(JSON.stringify({ statuscode: 200, response: data }));
                        }
                    })
                    break;
                case "/getAllData":
                    layer.getAllData(req, function(err, data) {
                        if (err)
                            res.end(JSON.stringify({ statuscode: 500, response: err }));
                        else {
                            res.end(JSON.stringify({ statuscode: 200, response: data }));
                        }
                    })

            }
            break;




        case "DELETE":
            switch (req.url) {
                case "/delete":
                    layer.deleteEmployee(req, function(err, data) {
                        if (err) {
                            res.end(JSON.stringify({ statuscode: 500, response: "unable to delete" }));
                        } else {
                            res.end(JSON.stringify({ statuscode: 200, response: " deleted " + data.eName }));
                        }
                    });

            }
            break;
        default:
            res.end("no routes found");
            break;
    }
}).listen(port, function() {
    console.log("server start at port " + port); //the server object listens on port 
});