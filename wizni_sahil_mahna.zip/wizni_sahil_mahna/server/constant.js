var dbURL = 'mongodb://localhost:27017/wizni';



module.exports = {
    dbURL: dbURL
}