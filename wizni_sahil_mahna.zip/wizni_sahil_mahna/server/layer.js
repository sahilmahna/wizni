var employee = require('./database/helper/employee-helper');
var manager = require('./database/helper/manager-helper');
var project = require('./database/helper/project-helper');

function create(req, callback) {

    getStringToJson(req, function(err, data) //getting json from buffer

        {

            if (err) {
                callback(err);
            } else {

                try {
                    var type = data.funName.toLowerCase();
                    if (type === "employee") { //for employee role
                        var object = { eId: data.eId, eName: data.eName, projects: data.project, manager: data.manager }
                        employee.registerEmployee(object, callback);
                    }
                    if (type === "manager") {
                        var object = { eId: data.eId, eName: data.eName, project: data.project, employee: data.employee }

                        manager.registerManager(object, callback);
                    }
                    if (type === "project") {
                        var object = { pId: data.pId, pName: data.pName, manager: data.manager, employees: data.employee }
                        project.registerProject(object, callback);
                    }
                } catch (e) { callback(e, null); }
            }
        }
    )
}



function update(req, callback) {

    getStringToJson(req, function(err, data)

        {

            if (err) {
                callback(err);
            } else {
                try {
                    var type = data.funName.toLowerCase();
                    if (type === "employee") {
                        employee.updateEmployee(data.args, callback);
                    }
                    if (type === "manager") {
                        manager.updateEmployee(data.args, callback);
                    }
                    if (type === "project") {
                        project.updateEmployee(data.args, callback);
                    }
                } catch (e) { callback(e, null); }
            }
        }
    )
}






function getData(req, callback) {

    getStringToJson(req, function(err, data)

        {
            if (err) {
                callback(err);
            } else {
                try {
                    var object = { eId: data.eId };

                    var type = data.funName.toLowerCase();
                    if (type === "employee") {
                        employee.getData(object, callback);
                    }
                    if (type === "manager") {
                        manager.getData(object, callback);
                    }
                    if (type === "project") {
                        var object = { pId: data.pId }
                        project.getData(object, callback);
                    }
                } catch (e) {
                    callback(e, null)
                }
            }

        });
}


function getAllData(req, callback) {
    getStringToJson(req, function(err, data)

        {
            if (err) {
                callback(err);
            } else {
                try {
                    var object = { eId: data.eId };
                    var type = data.funName.toLowerCase();
                    if (type === "employee") {
                        employee.getAllData(callback);
                    }
                    if (type === "manager") {
                        manager.getAllData(callback);
                    }
                    if (type === "project") {
                        var object = { pId: data.pId }
                        project.getAllData(callback);
                    }
                } catch (e) { callback(e, null) }
            }


        });
}


function deleteEmployee(req, callback) {

    getStringToJson(req, function(err, data)

        {


            if (err) {
                callback(err);
            } else {
                try {
                    var object = { eId: data.eId };

                    var type = data.funName.toLowerCase(); //getting role of the transaction
                    if (type === "employee") {
                        employee.deleteEmployee(object, callback);
                    }
                    if (type === "manager") {
                        manager.deleteManager(object, callback);
                    }
                    if (type === "project") {
                        var object = { pId: data.pId }
                        project.deleteProject(object, callback);
                    }
                } catch (e) {
                    callback(e, null);
                }
            }
        }

    )

}


function getStringToJson(req, callback) {
    let body = '';

    req.on('data', chunk => {
        body += chunk.toString(); // convert Buffer to string
    });

    req.on('end', () => {
        try {
            var result = JSON.parse(body);
        } catch (e) {
            callback(e, null);
        }
        callback(null, result)
    })
}
module.exports = {
    create: create,
    deleteEmployee: deleteEmployee,
    getData: getData,
    getAllData: getAllData,
    update: update
}